import { Component, OnInit } from '@angular/core';
import { RestoranService } from '../servisi/restoran.service';
import { Restoran } from '../models/restoran';
import { HttpClient } from '@angular/common/http';
import { Message } from '../models/message';


@Component({
  selector: 'app-adminrestorani',
  templateUrl: './adminrestorani.component.html',
  styleUrls: ['./adminrestorani.component.css']
})
export class AdminrestoraniComponent implements OnInit{

  constructor(private restoranServis: RestoranService, private http: HttpClient){}

  selectedFile: File | null= null
  fileContent: string = ""

  naziv: string = ""
  novoRadnoVremeOd : string = ""
  novoRadnoVremeDo : string = ""
  novoRadnoVremeOdVikend : string = ""
  novoRadnoVremeDoVikend : string = ""

  restorani: Restoran[] = []



  ngOnInit(): void {

        this.naziv = ""
        this.novoRadnoVremeDo = ""
        this.novoRadnoVremeOd = ""
        this.novoRadnoVremeDoVikend = ""
        this.novoRadnoVremeOdVikend = ""

      this.restoranServis.dohvatiRestorane().subscribe((res: Restoran[])=>{

        if(res){

          this.restorani = res;

        }

      })


  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];

      const reader = new FileReader();
      reader.onload = (e) => {
        this.fileContent = JSON.parse(reader.result as string);
      };
      reader.readAsText(this.selectedFile);
    }
  }

  dodajRestoran(){

    if (this.fileContent) {

      const data = {
        restoran : this.fileContent
      }

      this.http.post<Message>("http://localhost:4000/restoran/dodajRestoran", data).subscribe((msg: Message)=>{

        if(msg){

          alert("Uspešno dodat restoran!")
          window.location.reload()

        }

      }

      );
    }
  }

  dodajRadnoVreme(){

    this.restoranServis.dodajRadnoVreme(this.naziv,this.novoRadnoVremeOd, this.novoRadnoVremeDo, this.novoRadnoVremeOdVikend, this.novoRadnoVremeDoVikend).subscribe((msg: Message)=>{
        if(msg){
          alert("Uspesno azurirano radno vreme!")
        }
    })




  }







}
