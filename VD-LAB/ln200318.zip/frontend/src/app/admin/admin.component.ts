import { Component, OnInit } from '@angular/core';
import { Gost } from '../models/gost';
import { Konobar } from '../models/konobar';
import { KonobarService } from '../servisi/konobar.service';
import { GostService } from '../servisi/gost.service';
import { Router } from '@angular/router';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { Message } from '../models/message';
import { RestoranService } from '../servisi/restoran.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private restoranServis: RestoranService ,private konobarServis: KonobarService, private gostServis: GostService, private router: Router,private sanitizer: DomSanitizer){this.link = this.sanitizer.bypassSecurityTrustUrl('../../assets/rsz_blank-profile-picture-973460_1280.jpg');}



  selectedFile: string | null = null;
  selectedImage:string | null = null;

  greska1: boolean = false;
  greska2: boolean = false;
  greska3: boolean = false;
  greska4: boolean = false;

  formatLozinkaGreska : boolean = false

  link: SafeUrl

  gosti: Gost[] = []
  konobari: Konobar[] = []
  aktivniGosti: Gost[] = []
  neaktivniGost: Gost[] = []

  checkedPrihvati: boolean[] = []
  checkedOdbij: boolean[] = []

  izabran: string = ""

  imeNovo: string = ""
  prezimeNovo: string = ""
  adresaNova: string = ""
  emailNov: string = ""
  telefonNov: string = ""
  brojKreditneKarticeNov: string = ""

  gost: Gost = new Gost()
  konobar: Konobar = new Konobar()
  noviKonobar : Konobar = new Konobar()

  ngOnInit(): void {

    console.log(this.encryptMessage("Kono12!"))
    console.log(this.encryptMessage("Zveki12!"))
    console.log(this.encryptMessage("Kono12!"))
    console.log(this.encryptMessage("Luka12!"))
    console.log(this.encryptMessage("Stef12!"))
    console.log(this.encryptMessage("Lara12!"))

    this.noviKonobar.adresa = ""
    this.noviKonobar.bezbedonosnoPitanje= ""
    this.noviKonobar.brojKreditneKartice = ""
    this.noviKonobar.email = ""
    this.noviKonobar.ime = ""
    this.noviKonobar.kontaktTelefon = ""
    this.noviKonobar.korisnickoIme = ""
    this.noviKonobar.lozinka = ""
    this.noviKonobar.odgovor = ""
    this.noviKonobar.pol = ""
    this.noviKonobar.prezime = ""
    this.noviKonobar.profilnaSlika = null
    this.noviKonobar.restoran = ""

    this.gostServis.dohvatiGoste().subscribe((gos: Gost[])=>{

      if(gos){

        this.gosti = gos;

      }

      this.konobarServis.dohvatiKonobare().subscribe((kon: Konobar[])=>{

        if(kon){

          this.konobari = kon

        }

        this.gosti.forEach(g=>{
          if(g.aktivan == 1){
            this.aktivniGosti.push(g)
          }else if(g.aktivan == 0){
            this.neaktivniGost.push(g)
            this.checkedOdbij.push(false)
            this.checkedPrihvati.push(false)
          }
        })



      })

    })



  }

  onFileSelected(event: any): void {
    const fileInput = event.target;
    const file = (fileInput.files as FileList)[0];

    if (file) {
      // You can add additional logic here, such as validating the file type and size

      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = () => {
        this.selectedImage = reader.result as string;
      };
    }
  }

  decodeDataURL(dataURL: string): Blob {
    const parts = dataURL.split(',');
    const contentType = parts[0].split(':')[1];
    const raw = window.atob(parts[1]);
    const rawLength = raw.length;
    const uInt8Array = new Uint8Array(rawLength);

    for (let i = 0; i < rawLength; ++i) {
      uInt8Array[i] = raw.charCodeAt(i);
    }

    return new Blob([uInt8Array], { type: contentType });
  }

  validatePassword(password: string) {
    const regex = /^(?=.*[A-Z])(?=.*[a-z]{3})(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z][A-Za-z\d!@#$%^&*()_+]{5,9}$/;
    return regex.test(password);
  }

  encryptMessage(message: string): string {
    let encryptedMessage = '';
    for (let i = 0; i < message.length; i++) {
        let char = message[i];

        if (/[a-zA-Z]/.test(char)) {

            let code = message.charCodeAt(i);
            if (char === char.toUpperCase()) {
                char = String.fromCharCode(((code - 65 + 3) % 26) + 65);
            } else {
                char = String.fromCharCode(((code - 97 + 3) % 26) + 97);
            }
        }
        encryptedMessage += char;
    }
    return encryptedMessage;
}

  azuriraj(){

    this.gostServis.nadjiGostaUsername(this.izabran).subscribe((gost: Gost)=>{

      if(gost){

        this.gost = gost

        if(this.imeNovo != "")this.gost.ime = this.imeNovo
        if(this.prezimeNovo != "")this.gost.prezime = this.prezimeNovo
        if(this.emailNov != "")this.gost.email = this.emailNov
        if(this.adresaNova != "")this.gost.adresa = this.adresaNova
        if(this.telefonNov != "")this.gost.kontaktTelefon = this.telefonNov
        if(this.brojKreditneKarticeNov != "")this.gost.brojKreditneKartice = this.brojKreditneKarticeNov
        if(this.selectedImage){
          this.gost.profilnaSlika = this.selectedImage
          const blob = this.decodeDataURL(this.gost.profilnaSlika);
          this.link = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(blob));
        }

        this.gostServis.azurirajGosta(this.gost).subscribe((m: Message)=>{
          if(m){

            alert("Gost je uspešno ažuriran!")
            window.location.reload()


          }
        })



      }else{

        this.konobarServis.nadjiKonobaraUsername(this.izabran).subscribe((kon: Konobar)=>{

          if(kon){

            this.konobar = kon

            if(this.imeNovo != "")this.konobar.ime = this.imeNovo
            if(this.prezimeNovo != "")this.konobar.prezime = this.prezimeNovo
            if(this.emailNov != "")this.konobar.email = this.emailNov
            if(this.adresaNova != "")this.konobar.adresa = this.adresaNova
            if(this.telefonNov != "")this.konobar.kontaktTelefon = this.telefonNov
            if(this.selectedImage){
              this.konobar.profilnaSlika = this.selectedImage
              const blob = this.decodeDataURL(this.konobar.profilnaSlika);
              this.link = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(blob));
            }

            this.konobarServis.azurirajKonobara(this.konobar).subscribe((m: Message)=>{
              if(m){
                alert("Konobar je uspešno ažuriran!")
                window.location.reload()
              }
            })

          }

        })

      }

    })


  }


  sacuvaj(){

    let index = 0;

    for(let i =0; i < this.neaktivniGost.length;i++){

      if(this.checkedPrihvati[i]==true){

        this.gostServis.aktivirajGosta(this.neaktivniGost[i].korisnickoIme).subscribe((msg: Message)=>{

          if(msg){

            index++

          }

        })

      }else if(this.checkedOdbij[i] == true){

        this.gostServis.deaktivirajGosta(this.neaktivniGost[i].korisnickoIme).subscribe((msg: Message)=>{

          if(msg){
            index++
          }

        })

      }

    }

    if(index >0)alert("Uspešno ažuriranje!")
    window.location.reload()

  }

  submit(){

    this.noviKonobar.aktivan = 1

    this.noviKonobar.profilnaSlika = this.selectedImage

    if(this.noviKonobar.korisnickoIme == "" || this.noviKonobar.ime == "" || this.noviKonobar.prezime == ""|| this.noviKonobar.lozinka == "" || this.noviKonobar.odgovor == "" || this.noviKonobar.adresa == "" || this.noviKonobar.kontaktTelefon == "" || this.noviKonobar.email == "" || this.noviKonobar.restoran == ""){
      this.greska1 = true
      this.greska2 = false
      this.greska3 = false
      this.greska4 = false
      this.formatLozinkaGreska = false
    }else if( this.noviKonobar.bezbedonosnoPitanje == ""){

      this.greska1 = false
      this.greska2 = true
      this.greska3 = false
      this.greska4 = false
      this.formatLozinkaGreska = false

    }else if(this.noviKonobar.pol == ""){
      this.greska1 = false
      this.greska2 = false
      this.greska3 = true
      this.greska4 = false

      this.formatLozinkaGreska = false

    }else if(this.noviKonobar.profilnaSlika == null){
      this.greska1 = false
      this.greska2 = false
      this.greska3 = false
      this.greska4 = true
      this.formatLozinkaGreska = false
    }else if(!this.validatePassword(this.noviKonobar.lozinka)){
      this.greska1 = false
      this.greska2 = false
      this.greska3 = false
      this.greska4 = false
      this.formatLozinkaGreska = true
    }else{

      this.greska1 = false
      this.greska2 = false
      this.greska3 = false
      this.greska4 = false

      this.formatLozinkaGreska = false

      this.konobarServis.nadjiKonobaraUsername(this.noviKonobar.korisnickoIme).subscribe(
        (data: Konobar)=>{
          if(data)alert("Konobar sa unetim korisničkim imenom već postoji u sistemu!");else{

            this.konobarServis.nadjiKonobaraEmail(this.noviKonobar.email).subscribe(
              (data: Konobar)=>{
                if(data)alert("Konobar sa unetom email adresom već postoji!");
                else{

                  this.konobarServis.registracijaKonobra(this.noviKonobar).subscribe(
                    (msg: Message)=>{
                      if(msg.message == 'ok'){

                        this.restoranServis.dodajKonobaraZaRestoran(this.noviKonobar.restoran, this.noviKonobar.ime, this.noviKonobar.prezime).subscribe()

                        alert("Korisnik uspešno registrovan!")
                        window.location.reload()

                      }else{
                        alert("Korisnik nije registrovan!")
                      }
                    }
                  )

                }
              }
            )

          }
        }
      )






    }



  }

}
