import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KonobarrezervacijeComponent } from './konobarrezervacije.component';

describe('KonobarrezervacijeComponent', () => {
  let component: KonobarrezervacijeComponent;
  let fixture: ComponentFixture<KonobarrezervacijeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KonobarrezervacijeComponent]
    });
    fixture = TestBed.createComponent(KonobarrezervacijeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
