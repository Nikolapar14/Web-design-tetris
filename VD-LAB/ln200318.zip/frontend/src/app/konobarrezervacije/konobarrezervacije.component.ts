import { Component, OnInit } from '@angular/core';
import { Konobar } from '../models/konobar';
import { Rezervacija } from '../models/rezervacija';
import { RezervacijaService } from '../servisi/rezervacija.service';
import { Router } from '@angular/router';
import { Restoran } from '../models/restoran';
import { RestoranService } from '../servisi/restoran.service';
import { Message } from '../models/message';

@Component({
  selector: 'app-konobarrezervacije',
  templateUrl: './konobarrezervacije.component.html',
  styleUrls: ['./konobarrezervacije.component.css']
})
export class KonobarrezervacijeComponent implements OnInit{

  constructor(private rezervacijaServis : RezervacijaService, private router: Router, private restoranServis: RestoranService){}

  ulogovan: Konobar = new Konobar()
  rezervacijeNeobradjene: Rezervacija[] = []
  zaduzenjaKonobara: Rezervacija[] = []

  obrazlozenje: string = ""


  ngOnInit(): void {

    let ul = localStorage.getItem("ulogovan")
    if(ul)this.ulogovan = JSON.parse(ul)

    this.rezervacijaServis.dohvatiRezervacije().subscribe((rez: Rezervacija[])=>{
      if(rez){
        rez.forEach((r)=>{
          if(r.status == 0 && r.restoran == this.ulogovan.restoran){
            this.rezervacijeNeobradjene.push(r)
          }
          if(r.status == 1 && r.potvrda == 0 && r.gotov == 0 && r.zaduzenKonobar == this.ulogovan.korisnickoIme){
            this.zaduzenjaKonobara.push(r)
          }

        })

        this.rezervacijeNeobradjene.sort((a,b)=>{
          return a.rezervacijaOd.localeCompare(b.rezervacijaOd)
        })

        this.zaduzenjaKonobara.sort((a,b)=>{
          return a.rezervacijaOd.localeCompare(b.rezervacijaOd)
        })



      }



    })


  }

  prihvati(rezervacija: Rezervacija){

    localStorage.setItem("rezervacija", JSON.stringify(rezervacija))
    this.router.navigate(['canvaspregled'])

  }

  odbij(rezervacija: Rezervacija){

    rezervacija.status = 2
    rezervacija.gotov = 1
    rezervacija.opisOdgovor = this.obrazlozenje
    rezervacija.zaduzenKonobar = this.ulogovan.korisnickoIme


    this.rezervacijaServis.azurirajRezervaciju(rezervacija).subscribe((msg:Message)=>{
      if(msg){

        alert("Rezervacija odbijena!")
        window.location.reload()

      }
    })

  }

  potvrdiDolazak(rezervacija : Rezervacija){

    const rezervacijaOd: string = rezervacija.rezervacijaOd;
    const rezervacijaOdDate: Date = new Date(rezervacijaOd);

    const currentDate: Date = new Date();


    const timeDifference: number = currentDate.getTime() - rezervacijaOdDate.getTime();
    const differenceInMinutes: number = timeDifference / (1000 * 60);


    if (differenceInMinutes >= 30) {

        rezervacija.potvrda =1
        this.rezervacijaServis.azurirajRezervaciju(rezervacija).subscribe((msg: Message)=>{
          if(msg){
            alert("Potrvdjen dolazak!")
          }
        })

    } else {
      alert("Nije proslo pola sata od početka rezervacije!")
}

  }

  otkaziDolazak(rezervacija: Rezervacija){
    const rezervacijaOd: string = rezervacija.rezervacijaOd;
    const rezervacijaOdDate: Date = new Date(rezervacijaOd);

    const currentDate: Date = new Date();


    const timeDifference: number = currentDate.getTime() - rezervacijaOdDate.getTime();
    const differenceInMinutes: number = timeDifference / (1000 * 60);


    if (differenceInMinutes >= 30) {

        rezervacija.status =2
        rezervacija.gotov = 1

        rezervacija.opisOdgovor = "Gost se nije pojavio!"
        this.rezervacijaServis.azurirajRezervaciju(rezervacija).subscribe((msg: Message)=>{
          if(msg){
            alert("Rezervacija otkazana!")
          }
        })

    } else {
      alert("Nije proslo pola sata od početka rezervacije!")
    }
  }

}
