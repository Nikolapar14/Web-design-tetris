import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Konobar } from '../models/konobar';
import { Message } from '../models/message';

@Injectable({
  providedIn: 'root'
})
export class KonobarService {

  constructor(private http: HttpClient) { }

  nadjiKonobaraUsername(username: String){
    const data = {
      username: username
    }

    return this.http.post<Konobar>("http://localhost:4000/konobar/nadjiKonobaraUsername",data)

  }

  nadjiKonobaraEmail(email: string) {

    const data = {
      email : email
    }

    return this.http.post<Konobar>("http://localhost:4000/konobar/nadjiKonobaraEmail",data)
  }



  loginKonobar(username: String, password: String ){

    const data = {

      username: username,
      password: password

    }

    return this.http.post<Konobar>("http://localhost:4000/konobar/login",data)

  }

  promenaSifre(username: String, novaLozinka: String, staraLozinka: String ){

    const data = {

      username: username,
      staraLozinka : staraLozinka,
      novaLozinka : novaLozinka

    }

    return this.http.post<Message>("http://localhost:4000/konobar/promenaLozinke", data)

  }

  azurirajKonobara(konobar: Konobar){

    const data = {
      konobar: konobar
    }

    return this.http.post<Message>("http://localhost:4000/konobar/azurirajKonobara",data)

  }

  dohvatiKonobare(){

    return this.http.get<Konobar[]>("http://localhost:4000/konobar/dohvatiKonobare")
  }

  registracijaKonobra(konobar: Konobar){

    const data = {

      konobar : konobar

    }

    return this.http.post<Message>("http://localhost:4000/konobar/registracijaKonobra",data)

  }




}
