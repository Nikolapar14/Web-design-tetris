import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Restoran } from '../models/restoran';
import { Message } from '../models/message';

@Injectable({
  providedIn: 'root'
})
export class RestoranService {

  constructor(private http: HttpClient) { }

  dohvatiRestorane(){

    return this.http.get<Restoran[]>("http://localhost:4000/restoran/dohvatiRestorane")
  }

  dodajRadnoVreme(nazivRestorana: string,novoRadnoVremeOd: string, novoRadnoVremeDo: string, novoRadnoVremeOdVikend: string, novoRadnoVremeDoVikend: string){

    const data = {

      nazivRestorana: nazivRestorana,
      novoRadnoVremeOd : novoRadnoVremeOd,
      novoRadnoVremeDo : novoRadnoVremeDo,
      novoRadnoVremeOdVikend : novoRadnoVremeOdVikend,
      novoRadnoVremeDoVikend : novoRadnoVremeDoVikend


    }

    return  this.http.post<Message>("http://localhost:4000/restoran/dodajRadnoVreme",data)


  }

  dodajKonobaraZaRestoran(nazivRestorana: string, imeKonobara: string, prezimeKonobara: string){



    const data = {

      nazivRestorana: nazivRestorana,
      imePrezime : imeKonobara + " " + prezimeKonobara

    }

    return  this.http.post<Message>("http://localhost:4000/restoran/dodajKonobaraZaRestoran",data)


  }


}
