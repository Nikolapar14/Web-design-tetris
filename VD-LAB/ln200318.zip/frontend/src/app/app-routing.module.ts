import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { NeregistrovaniComponent } from './neregistrovani/neregistrovani.component';
import { RegistracijaComponent } from './registracija/registracija.component';
import { GostComponent } from './gost/gost.component';
import { KonobarComponent } from './konobar/konobar.component';
import { PromenaLozinkeComponent } from './promena-lozinke/promena-lozinke.component';
import { ZaboravljenaLozinkaComponent } from './zaboravljena-lozinka/zaboravljena-lozinka.component';
import { AdminpocetnaComponent } from './adminpocetna/adminpocetna.component';
import { AdminComponent } from './admin/admin.component';
import { AdminrestoraniComponent } from './adminrestorani/adminrestorani.component';
import { GostrestoraniComponent } from './gostrestorani/gostrestorani.component';
import { RestoranprikazComponent } from './restoranprikaz/restoranprikaz.component';
import { GostdostaveComponent } from './gostdostave/gostdostave.component';
import { KonobardostaveComponent } from './konobardostave/konobardostave.component';
import { GostrezervacijeComponent } from './gostrezervacije/gostrezervacije.component';
import { KonobarrezervacijeComponent } from './konobarrezervacije/konobarrezervacije.component';
import { CanvaspregledComponent } from './canvaspregled/canvaspregled.component';
import { StatistikaComponent } from './statistika/statistika.component';

const routes: Routes = [

  {path:"",component:NeregistrovaniComponent},
  {path:"registracija", component:RegistracijaComponent},
  {path:"login", component:LoginComponent},
  {path:"gost", component:GostComponent},
  {path:"konobar", component:KonobarComponent},
  {path:"promenaLozinke",component:PromenaLozinkeComponent},
  {path:"zaboravljena", component:ZaboravljenaLozinkaComponent},
  {path:"adminpocetna", component:AdminpocetnaComponent},
  {path:"admin", component:AdminComponent},
  {path:"adminrestorani", component: AdminrestoraniComponent},
  {path:"gostrestorani", component: GostrestoraniComponent},
  {path:"restoranprikaz", component: RestoranprikazComponent},
  {path: "gostdostave", component: GostdostaveComponent},
  {path:"konobardostave", component: KonobardostaveComponent},
  {path: "gostrezervacije", component: GostrezervacijeComponent},
  {path:"konobarrezervacije", component: KonobarrezervacijeComponent},
  {path:"canvaspregled", component: CanvaspregledComponent},
  {path:"statistika", component: StatistikaComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
