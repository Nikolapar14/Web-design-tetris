import { Component, OnInit } from '@angular/core';
import { RestoranService } from '../servisi/restoran.service';
import { KonobarService } from '../servisi/konobar.service';
import { Router } from '@angular/router';
import { Restoran } from '../models/restoran';
import { GostService } from '../servisi/gost.service';
import { Gost } from '../models/gost';
import { Rezervacija } from '../models/rezervacija';
import { RezervacijaService } from '../servisi/rezervacija.service';

@Component({
  selector: 'app-neregistrovani',
  templateUrl: './neregistrovani.component.html',
  styleUrls: ['./neregistrovani.component.css']
})
export class NeregistrovaniComponent implements OnInit {

  constructor(private restoraniServis: RestoranService, private konobarServis: KonobarService, private router: Router, private gostServis: GostService, private rezervacijaServis: RezervacijaService){}

  restorani : Restoran[] = []
  restoraniPoNazivuNeopadajuce : Restoran[] = []
  restoraniPoNazivuNerastuce : Restoran[] = []
  restoraniPoTipuNeopadajuce: Restoran[] = []
  restoraniPoTipuNerastuce : Restoran[] = []
  restoraniPoAdresiNeopadajuce: Restoran[] = []
  restoraniPoAdresiNerastuce: Restoran[] = []


  gosti: Gost[] = []
  aktivniGosti: Gost[] = []

  rezervacije: Rezervacija[] = []
  gotoveRezervacije: Rezervacija[] = []

  rezervacijeUSedamDana: number = 0
  rezervacijeUDanu: number = 0
  rezervacijeUMesecDana: number = 0

  radio1: string = ""
  radio2: string = ""

  nazivRestorana: string = ""
  tipRestorana: string = ""
  adresaRestorana: string = ""


  ngOnInit(): void {

    this.rezervacijeUDanu = 0
    this.rezervacijeUMesecDana = 0
    this.rezervacijeUSedamDana = 0

    this.restoraniServis.dohvatiRestorane().subscribe((res: Restoran[])=>{

      if(res){

        this.restorani = res

        this.restorani.forEach(r=>{
          this.restoraniPoNazivuNeopadajuce.push(r)
          this.restoraniPoNazivuNerastuce.push(r)
          this.restoraniPoAdresiNeopadajuce.push(r)
          this.restoraniPoAdresiNerastuce.push(r)
          this.restoraniPoTipuNerastuce.push(r)
          this.restoraniPoTipuNeopadajuce.push(r)
        })

        this.restoraniPoNazivuNeopadajuce.sort((a,b)=>{
           return a.naziv.localeCompare(b.naziv)
        })

        this.restoraniPoNazivuNerastuce.sort((a,b)=>{
          return b.naziv.localeCompare(a.naziv)
       })

       this.restoraniPoAdresiNeopadajuce.sort((a,b)=>{
        return a.adresa.localeCompare(b.adresa)
       })

       this.restoraniPoAdresiNerastuce.sort((a,b)=>{
        return b.adresa.localeCompare(a.adresa)
       })

       this.restoraniPoTipuNeopadajuce.sort((a,b)=>{
        return a.tip.localeCompare(b.tip)
       })

       this.restoraniPoTipuNerastuce.sort((a,b)=>{
        return b.tip.localeCompare(a.tip)
       })



        this.gostServis.dohvatiGoste().subscribe((gos: Gost[])=>{

          if(gos){
            this.gosti = gos

            this.gosti.forEach((g)=>{
              if(g.aktivan==1){
                this.aktivniGosti.push(g)
              }



            })

          }

        })

        this.rezervacijaServis.dohvatiRezervacije().subscribe((rez: Rezervacija[])=>{

          if(rez){

            this.rezervacije = rez

            this.rezervacije.forEach((r)=>{
              if(r.gotov == 1 && r.status == 1){
                this.gotoveRezervacije.push(r)
              }
            })

            this.calculateReservations()



          }

        })

      }

    })

  }

  calculateReservations() {
    const now = new Date();
    this.gotoveRezervacije.forEach(reservation => {
      const rezervacijaOdDate = new Date(reservation.rezervacijaOd);

      const timeDifference = now.getTime() - rezervacijaOdDate.getTime();
      const daysDifference = timeDifference / (1000 * 3600 * 24);

      if (daysDifference <= 1) {
        this.rezervacijeUDanu++;
      }
      if (daysDifference <= 7) {
        this.rezervacijeUSedamDana++;
      }
      if (daysDifference <= 30) {
        this.rezervacijeUMesecDana++;
      }
    });
  }

}
