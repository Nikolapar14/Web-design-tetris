import { Component, OnInit } from '@angular/core';
import { RestoranService } from '../servisi/restoran.service';
import { KonobarService } from '../servisi/konobar.service';
import { Router } from '@angular/router';
import { GostService } from '../servisi/gost.service';
import { RezervacijaService } from '../servisi/rezervacija.service';
import { Restoran } from '../models/restoran';

@Component({
  selector: 'app-gostrestorani',
  templateUrl: './gostrestorani.component.html',
  styleUrls: ['./gostrestorani.component.css']
})
export class GostrestoraniComponent implements OnInit{

  constructor(private restoraniServis: RestoranService, private konobarServis: KonobarService, private router: Router, private gostServis: GostService, private rezervacijaServis: RezervacijaService){}

  restorani : Restoran[] = []

  nazivRestorana: string = ""
  tipRestorana: string = ""
  adresaRestorana: string = ""

  restoran: Restoran = new Restoran()


  ngOnInit(): void {

    this.restoraniServis.dohvatiRestorane().subscribe((res: Restoran[])=>{
      if(res){
        this.restorani = res
      }
    })

  }

  prepare(e: Event, naziv: string){

    e.preventDefault()

    this.restorani.forEach(res =>{
      if(res.naziv == naziv){

        localStorage.setItem("restoran", JSON.stringify(res))
        this.router.navigate(['restoranprikaz'])

      }
    })


  }

}
