import { Component, OnInit } from '@angular/core';
import { Restoran } from '../models/restoran';
import { Gost } from '../models/gost';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { DostavaService } from '../servisi/dostava.service';
import { Dostava } from '../models/dostava';
import { Message } from '../models/message';
import { Rezervacija } from '../models/rezervacija';
import { RezervacijaService } from '../servisi/rezervacija.service';

@Component({
  selector: 'app-restoranprikaz',
  templateUrl: './restoranprikaz.component.html',
  styleUrls: ['./restoranprikaz.component.css']
})
export class RestoranprikazComponent implements OnInit {

  constructor(private sanitizer: DomSanitizer, private dostavaServis: DostavaService, private rezervacijaServis: RezervacijaService){
    this.link = this.sanitizer.bypassSecurityTrustUrl('../../assets/rsz_blank-profile-picture-973460_1280.jpg');
  }

  korpa : string[] = []
  brojIzabranih: number[] = []
  brojIzabranihUkupno: number[] = []


  link: SafeUrl;

  selectedFile: string | null = null;
  selectedImage:string | null = null;

  restoran : Restoran = new Restoran()
  ulogovan : Gost = new Gost()

  novaDostava: Dostava = new Dostava()

  vremePocetka: string = ""
  vremeKraja: string = ""
  brojOsoba: number = 0
  dodatniZahtevi: string = ""

  rezervacija: Rezervacija = new Rezervacija()

  ngOnInit(): void {

    let res = localStorage.getItem("restoran")
    if(res)this.restoran = JSON.parse(res)

    let index = 0
    this.restoran.jelovnik.forEach((j)=>{
      this.brojIzabranih[index] = 0
      this.brojIzabranihUkupno[index] = 0
      index++
    })

    let ul = localStorage.getItem("ulogovan")
    if(ul)this.ulogovan = JSON.parse(ul)



  }

  onFileSelected(event: any): void {
    const fileInput = event.target;
    const file = (fileInput.files as FileList)[0];

    if (file) {
      // You can add additional logic here, such as validating the file type and size

      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = () => {
        this.selectedImage = reader.result as string;
      };
    }
  }

  decodeDataURL(dataURL: string): Blob {
    const parts = dataURL.split(',');
    const contentType = parts[0].split(':')[1];
    const raw = window.atob(parts[1]);
    const rawLength = raw.length;
    const uInt8Array = new Uint8Array(rawLength);

    for (let i = 0; i < rawLength; ++i) {
      uInt8Array[i] = raw.charCodeAt(i);
    }

    return new Blob([uInt8Array], { type: contentType });
  }

  dodajUKorpu(){

    for(let i = 0; i< this.brojIzabranih.length; i++){
      this.brojIzabranihUkupno[i] += this.brojIzabranih[i]

    }

    alert("Uspešno dodato!")
    console.log(this.brojIzabranihUkupno)

  }

  pregledKorpe(){

    let ispis = ""

    let cena = 0



    for(let i = 0; i < this.restoran.jelovnik.length; i++){
      ispis += this.brojIzabranihUkupno[i] + "x" + this.restoran.jelovnik[i].jelo + ", "
      cena += this.restoran.jelovnik[i].cena * this.brojIzabranihUkupno[i]
    }

    ispis += "cena: " + cena.toString()

    alert(ispis)

  }

  poruci(){

    let ispis = ""
    let cena = 0
    for(let i = 0; i < this.restoran.jelovnik.length; i++){
      ispis += this.brojIzabranihUkupno[i] + "x" + this.restoran.jelovnik[i].jelo + ", "
      cena += this.restoran.jelovnik[i].cena * this.brojIzabranihUkupno[i]
    }

    ispis += "cena: " + cena.toString()

    for(let i = 0; i <this.brojIzabranihUkupno.length;i++){
      this.brojIzabranihUkupno[i] = 0
    }

    this.novaDostava.korisnickoIme = this.ulogovan.korisnickoIme
    this.novaDostava.ocekivanoVreme = ""
    this.novaDostava.porudzbina = ispis
    this.novaDostava.restoran = this.restoran.naziv
    this.novaDostava.status = 0

    this.dostavaServis.dodajDostavu(this.novaDostava).subscribe((msg:Message)=>{

      if(msg){
        alert("Vaša porudžbina je evidentirana, sačekajte potvrdu restorana!")
        window.location.reload()
      }

    })





  }

  posaljiZahtev(){
    this.rezervacija.brojMesta = this.brojOsoba
    this.rezervacija.gotov = 0
    this.rezervacija.korisnickoIme = this.ulogovan.korisnickoIme
    this.rezervacija.opisOdgovor = ""
    this.rezervacija.restoran = this.restoran.naziv
    this.rezervacija.rezervacijaOd = this.vremePocetka
    this.rezervacija.rezervacijaDo = this.vremeKraja
    this.rezervacija.status = 0
    this.rezervacija.sto = 0
    this.rezervacija.zaduzenKonobar = ""

    this.rezervacijaServis.dodajRezervaciju(this.rezervacija).subscribe((msg : Message)=>{
      if(msg){

        alert("Zahtev uspešno poslat!")
        window.location.reload()
      }
    })


  }

}
