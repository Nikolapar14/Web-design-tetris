import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestoranprikazComponent } from './restoranprikaz.component';

describe('RestoranprikazComponent', () => {
  let component: RestoranprikazComponent;
  let fixture: ComponentFixture<RestoranprikazComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RestoranprikazComponent]
    });
    fixture = TestBed.createComponent(RestoranprikazComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
