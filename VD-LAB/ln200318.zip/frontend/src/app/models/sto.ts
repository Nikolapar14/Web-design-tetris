export class Sto{

  idStola: number = 0
  brojMesta: number = 0

}
