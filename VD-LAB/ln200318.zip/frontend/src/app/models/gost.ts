export class Gost{

  korisnickoIme: string = ""
  lozinka: string = ""
  bezbedonosnoPitanje: string = ""
  odgovor: string = ""
  ime: string =  ""
  prezime: string =  ""
  pol: string = ""
  adresa: string = ""
  kontaktTelefon: string = ""
  email: string = ""
  profilnaSlika: string | null = null
  brojKreditneKartice: string = ""
  aktivan: number = 0




}
