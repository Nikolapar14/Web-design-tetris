export class Dostava{

  korisnickoIme : string = ""
  restoran : string = ""
  status : number = 0
  ocekivanoVreme: string = ""
  porudzbina: string = ""

}
