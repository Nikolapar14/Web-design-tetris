import { Jelo } from "./jelo"
import { Sto } from "./sto"

export class Restoran {

  naziv : string = ""
  tip: string = ""
  adresa : string = ""
  opis : string = ""
  kontaktTelefon: string = ""
  radnoVremeOdRD : string = ""
  radnoVremeDoRD: string = ""
  radnoVremeOdVikend: string = ""
  radnoVremeDoVikend: string = ""
  profilnaSlika: string = ""
  brojStolova: number = 0
  brojKupatila: number = 0
  brojKuhinja: number = 0
  stolovi: Sto[] = []
  jelovnik: Jelo[] = []
  konobari : string[] = []


}
