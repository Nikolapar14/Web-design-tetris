export class Rezervacija{

  restoran : string = ""
  korisnickoIme: string = ""
  rezervacijaOd: string = ""
  rezervacijaDo: string = ""
  brojMesta : number = 0
  sto: number = 0
  status: number = 0
  zaduzenKonobar: string = ""
  opisOdgovor: string = ""
  gotov: number = 0
  potvrda: number = 0


}
