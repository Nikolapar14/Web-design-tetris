import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { Message } from '../models/message';
import { GostService } from '../servisi/gost.service';
import { Gost } from '../models/gost';

@Component({
  selector: 'app-zaboravljena-lozinka',
  templateUrl: './zaboravljena-lozinka.component.html',
  styleUrls: ['./zaboravljena-lozinka.component.css']
})
export class ZaboravljenaLozinkaComponent implements OnInit {

  constructor(private gostServis: GostService, private router: Router){}

  korisnickoIme: string = ""
  pitanje: string = ""
  potvrda: boolean = false
  odgovor: string = ""
  netacanOdgovor: boolean = false
  dalje: boolean = false
  staraLozinka: string = ""
  novaLozinka: string = ""
  novaLozinka2: string = ""
  poruka: string = ""

  gost: Gost = new Gost();



  ngOnInit(): void {

  }

  encryptMessage(message: string): string {
    let encryptedMessage = '';
    for (let i = 0; i < message.length; i++) {
        let char = message[i];

        if (/[a-zA-Z]/.test(char)) {

            let code = message.charCodeAt(i);
            if (char === char.toUpperCase()) {
                char = String.fromCharCode(((code - 65 + 3) % 26) + 65);
            } else {
                char = String.fromCharCode(((code - 97 + 3) % 26) + 97);
            }
        }
        encryptedMessage += char;
    }
    return encryptedMessage;
}

  potvrdi(){

    this.potvrda = false
    this.dalje = false
    this.netacanOdgovor = false

    this.gostServis.nadjiGostaUsername(this.korisnickoIme).subscribe((g: Gost)=>{

      if(g){

        this.gost = g

        this.poruka = ""
        this.potvrda = true

        this.pitanje = this.gost.bezbedonosnoPitanje

      }else{
        this.poruka = "Korisnik sa unetim korisničkim imenom ne postoji!"
      }

    })

  }

  proveriOdgovor(){

    this.netacanOdgovor = false
    this.dalje = false

    if(this.korisnickoIme == this.gost.korisnickoIme){
      if(this.odgovor == this.gost.odgovor){
        this.dalje = true
      }else{
        this.netacanOdgovor = true
      }
    }

  }

  validatePassword(password: string) {
    const regex = /^(?=.*[A-Z])(?=.*[a-z]{3})(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z][A-Za-z\d!@#$%^&*()_+]{5,9}$/;
    return regex.test(password);
  }



  promeniLozinku(){

    if( this.novaLozinka == "" || this.novaLozinka2==""){
      this.poruka = "Popunite sva polja"

    }
    else{

      this.gost.lozinka = this.encryptMessage(this.gost.lozinka)

      this.gostServis.loginGost(this.korisnickoIme,this.gost.lozinka).subscribe((gost: Gost) =>{

        if(gost){

          if(!this.validatePassword(this.novaLozinka)){

            this.poruka = "Format nove lozinke nije odgovarajuci!"

          }else{
            if(this.novaLozinka != this.novaLozinka2){
              this.poruka = "Lozinke se ne poklapaju"
            }else{

              this.novaLozinka = this.encryptMessage(this.novaLozinka)

              this.gostServis.promenaSifre(this.korisnickoIme,this.novaLozinka, this.gost.lozinka).subscribe((mes: Message) =>{

                if(mes){

                  alert("Sifra je uspesno promenjena!")
                  this.router.navigate(['login'])
                }

              })
            }
          }
        }else{
          this.poruka = "Neispravno uneti podaci!"
        }

      })

    }






  }



}
