import { Component, OnInit } from '@angular/core';
import { Konobar } from '../models/konobar';
import { Rezervacija } from '../models/rezervacija';
import { RezervacijaService } from '../servisi/rezervacija.service';
import { Restoran } from '../models/restoran';
import { RestoranService } from '../servisi/restoran.service';
import { Message } from '../models/message';

@Component({
  selector: 'app-canvaspregled',
  templateUrl: './canvaspregled.component.html',
  styleUrls: ['./canvaspregled.component.css']
})
export class CanvaspregledComponent implements OnInit {

  constructor(private rezervacijaServis: RezervacijaService, private restoranServis: RestoranService) {}

  ulogovan: Konobar = new Konobar();
  rezervacija: Rezervacija = new Rezervacija();
  restoran: Restoran = new Restoran();

  rezervacijePredstojece: Rezervacija[] = [];
  slobodniStolovi: number[] = [];

  izabranSto: string = ""

  ngOnInit(): void {
    let ul = localStorage.getItem("ulogovan");
    if (ul) this.ulogovan = JSON.parse(ul);

    let rez = localStorage.getItem("rezervacija");
    if (rez) this.rezervacija = JSON.parse(rez);

    this.rezervacijaServis.dohvatiRezervacije().subscribe((rez: Rezervacija[]) => {
      if (rez) {
        rez.forEach(r => {
          if (r.restoran === this.ulogovan.restoran && r.status === 1 && r.gotov === 0) {
            this.rezervacijePredstojece.push(r);
          }
        });

        this.restoranServis.dohvatiRestorane().subscribe((res: Restoran[]) => {
          if (res) {
            for (let i = 0; i < res.length; i++) {
              if (res[i].naziv === this.ulogovan.restoran) {
                this.restoran = res[i];
                break;
              }
            }
            this.pronadjiSlobodneStolove();
            console.log(this.slobodniStolovi);
            this.iscrtajRestoran();
          }
        });
      }
    });
  }

  potvrdiSto(){
    this.rezervacija.sto = parseInt(this.izabranSto)
    this.rezervacija.status = 1
    this.rezervacija.zaduzenKonobar = this.ulogovan.korisnickoIme

    this.rezervacijaServis.azurirajRezervaciju(this.rezervacija).subscribe((msg:Message)=>{
      if(msg){
        alert("Sto potvrdjen!")
        window.location.reload()
      }
    })

  }

  private preklapaSe(rez1: Rezervacija, rez2: Rezervacija): boolean {
    return (new Date(rez1.rezervacijaOd) < new Date(rez2.rezervacijaDo) &&
            new Date(rez1.rezervacijaDo) > new Date(rez2.rezervacijaOd));
  }

  private pronadjiSlobodneStolove(): void {
    const sviStolovi = this.restoran.stolovi.map(sto => sto.idStola);
    const zauzetiStolovi = new Set<number>();

    this.rezervacijePredstojece.forEach(r => {
      if (this.preklapaSe(this.rezervacija, r)) {
        zauzetiStolovi.add(r.sto);
      }
    });

    this.slobodniStolovi = sviStolovi.filter(sto => {
      const stoDetalji = this.restoran.stolovi.find(s => s.idStola === sto);
      return stoDetalji && stoDetalji.brojMesta >= this.rezervacija.brojMesta && !zauzetiStolovi.has(sto);
    });
  }

  private iscrtajRestoran(): void {
    const canvas = document.getElementById('restaurantCanvas') as HTMLCanvasElement;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      return;
    }

    // Postavljanje bele pozadine
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const margin = 30;
    const radius = 50; // Povećanje veličine stolova
    const kupatiloSize = 100;
    const kuhinjaSize = 100;

    // Definisanje oblasti za kupatilo i kuhinju
    const kupatiloY = canvas.height - kupatiloSize - margin;
    const kuhinjaX = canvas.width - kuhinjaSize - margin;

    // Iscrtavanje kupatila
    for (let i = 0; i < this.restoran.brojKupatila; i++) {
      ctx.fillStyle = 'blue';
      ctx.fillRect(margin + i * (kupatiloSize + margin), kupatiloY, kupatiloSize, kupatiloSize);
      ctx.fillStyle = 'black';
      ctx.font = '20px Arial';
      ctx.fillText('Kupatilo', margin + i * (kupatiloSize + margin) + 10, kupatiloY + 50);
    }

    // Iscrtavanje kuhinja
    for (let i = 0; i < this.restoran.brojKuhinja; i++) {
      ctx.fillStyle = 'yellow';
      ctx.fillRect(kuhinjaX, margin + i * (kuhinjaSize + margin), kuhinjaSize, kuhinjaSize);
      ctx.fillStyle = 'black';
      ctx.font = '20px Arial';
      ctx.fillText('Kuhinja', kuhinjaX + 10, margin + i * (kuhinjaSize + margin) + 50);
    }

    // Definisanje tipa za placedObjects
    interface PlacedObject {
      x: number;
      y: number;
      radius: number;
    }
    const placedObjects: PlacedObject[] = [];

    // Funkcija za proveru preklapanja
    const checkOverlap = (x: number, y: number, radius: number, objects: PlacedObject[]): boolean => {
      for (const obj of objects) {
        const dx = x - obj.x;
        const dy = y - obj.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < radius + obj.radius + margin) {
          return true;
        }
      }
      return false;
    };

    // Raspored u kvadratnu mrežu
    const gridSpacing = radius * 2 + margin;
    const tablesPerGroup = Math.ceil(this.restoran.stolovi.length / 2);
    const gridSize = Math.ceil(Math.sqrt(tablesPerGroup));

    // Iscrtavanje stolova na simetrične pozicije
    this.restoran.stolovi.forEach((sto, index) => {
      let x, y;
      if (index < tablesPerGroup) {
        x = margin + (index % gridSize) * gridSpacing + radius;
        y = margin + Math.floor(index / gridSize) * gridSpacing + radius;
      } else {
        x = canvas.width / 2 + margin + (index % gridSize) * gridSpacing + radius;
        y = canvas.height / 2 + margin + Math.floor((index - tablesPerGroup) / gridSize) * gridSpacing + radius;
      }

      placedObjects.push({ x, y, radius });

      const isZauzet = !this.slobodniStolovi.includes(sto.idStola);
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, 2 * Math.PI);
      ctx.fillStyle = isZauzet ? 'red' : 'white';
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = 'black';
      ctx.font = '20px Arial';
      ctx.fillText(sto.idStola.toString(), x - 15, y + 5);
    });
  }
}
