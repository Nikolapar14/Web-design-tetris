import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { Message } from '../models/message';
import { GostService } from '../servisi/gost.service';
import { Gost } from '../models/gost';

@Component({
  selector: 'app-gost',
  templateUrl: './gost.component.html',
  styleUrls: ['./gost.component.css']
})
export class GostComponent implements OnInit {
  constructor(
    private gostServis: GostService,
    private sanitizer: DomSanitizer
  ) {
    this.link = this.sanitizer.bypassSecurityTrustUrl('../../assets/rsz_blank-profile-picture-973460_1280.jpg');
  }

  ulogovan: Gost = new Gost()
  link: SafeUrl;

  selectedFile: string | null = null;
  selectedImage:string | null = null;

  imeNovo: string = ""
  prezimeNovo: string = ""
  adresaNova: string = ""
  emailNov: string = ""
  telefonNov: string = ""
  brojKreditneKarticeNov: string = ""


  ngOnInit(): void {
    let korisnik = localStorage.getItem('ulogovan');
    if (korisnik != null) this.ulogovan = JSON.parse(korisnik);

    localStorage.setItem("gost", JSON.stringify(this.ulogovan))

    if (this.ulogovan.profilnaSlika != null) {
      const blob = this.decodeDataURL(this.ulogovan.profilnaSlika);
      this.link = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(blob));
    }
  }

  onFileSelected(event: any): void {
    const fileInput = event.target;
    const file = (fileInput.files as FileList)[0];

    if (file) {
      // You can add additional logic here, such as validating the file type and size

      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = () => {
        this.selectedImage = reader.result as string;
      };
    }
  }

  decodeDataURL(dataURL: string): Blob {
    const parts = dataURL.split(',');
    const contentType = parts[0].split(':')[1];
    const raw = window.atob(parts[1]);
    const rawLength = raw.length;
    const uInt8Array = new Uint8Array(rawLength);

    for (let i = 0; i < rawLength; ++i) {
      uInt8Array[i] = raw.charCodeAt(i);
    }

    return new Blob([uInt8Array], { type: contentType });
  }

  azuriraj(){

    if(this.imeNovo != "")this.ulogovan.ime = this.imeNovo
    if(this.prezimeNovo != "")this.ulogovan.prezime = this.prezimeNovo
    if(this.emailNov != "")this.ulogovan.email = this.emailNov
    if(this.adresaNova != "")this.ulogovan.adresa = this.adresaNova
    if(this.telefonNov != "")this.ulogovan.kontaktTelefon = this.telefonNov
    if(this.brojKreditneKarticeNov != "")this.ulogovan.brojKreditneKartice = this.brojKreditneKarticeNov
    if(this.selectedImage){
      this.ulogovan.profilnaSlika = this.selectedImage
      const blob = this.decodeDataURL(this.ulogovan.profilnaSlika);
      this.link = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(blob));
    }



    this.gostServis.azurirajGosta(this.ulogovan).subscribe((msg: Message)=>{
      if(msg){

        alert("Gost uspesno azuriran!")



      }
    })


  }




}
