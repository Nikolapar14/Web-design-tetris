import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { RegistracijaComponent } from './registracija/registracija.component';
import { NeregistrovaniComponent } from './neregistrovani/neregistrovani.component';
import { GostComponent } from './gost/gost.component';
import { KonobarComponent } from './konobar/konobar.component';
import { ZaboravljenaLozinkaComponent } from './zaboravljena-lozinka/zaboravljena-lozinka.component';
import { PromenaLozinkeComponent } from './promena-lozinke/promena-lozinke.component';
import { AdminpocetnaComponent } from './adminpocetna/adminpocetna.component';
import { AdminComponent } from './admin/admin.component';
import { AdminrestoraniComponent } from './adminrestorani/adminrestorani.component';
import { GostrestoraniComponent } from './gostrestorani/gostrestorani.component';
import { RestoranprikazComponent } from './restoranprikaz/restoranprikaz.component';
import { GostdostaveComponent } from './gostdostave/gostdostave.component';
import { KonobardostaveComponent } from './konobardostave/konobardostave.component';
import { GostrezervacijeComponent } from './gostrezervacije/gostrezervacije.component';
import { KonobarrezervacijeComponent } from './konobarrezervacije/konobarrezervacije.component';
import { CanvaspregledComponent } from './canvaspregled/canvaspregled.component';
import { StatistikaComponent } from './statistika/statistika.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistracijaComponent,
    NeregistrovaniComponent,
    GostComponent,
    KonobarComponent,
    ZaboravljenaLozinkaComponent,
    PromenaLozinkeComponent,
    AdminpocetnaComponent,
    AdminComponent,
    AdminrestoraniComponent,
    GostrestoraniComponent,
    RestoranprikazComponent,
    GostdostaveComponent,
    KonobardostaveComponent,
    GostrezervacijeComponent,
    KonobarrezervacijeComponent,
    CanvaspregledComponent,
    StatistikaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
