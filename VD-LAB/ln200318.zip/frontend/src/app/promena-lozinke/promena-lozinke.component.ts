import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GostService } from '../servisi/gost.service';

import { Gost } from '../models/gost';

import { Message } from '../models/message';

@Component({
  selector: 'app-promena-lozinke',
  templateUrl: './promena-lozinke.component.html',
  styleUrls: ['./promena-lozinke.component.css']
})
export class PromenaLozinkeComponent implements OnInit{

  constructor(private gostServis: GostService, private router: Router){}

  korisnickoIme: string = ""
  staraLozinka: string = ""
  novaLozinka: string = ""
  novaLozinka2: string = ""
  poruka: string = ""

  ngOnInit(): void {

  }

  validatePassword(password: string) {
    const regex = /^(?=.*[A-Z])(?=.*[a-z]{3})(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z][A-Za-z\d!@#$%^&*()_+]{5,9}$/;
    return regex.test(password);
  }

  encryptMessage(message: string): string {
    let encryptedMessage = '';
    for (let i = 0; i < message.length; i++) {
        let char = message[i];

        if (/[a-zA-Z]/.test(char)) {

            let code = message.charCodeAt(i);
            if (char === char.toUpperCase()) {
                char = String.fromCharCode(((code - 65 + 3) % 26) + 65);
            } else {
                char = String.fromCharCode(((code - 97 + 3) % 26) + 97);
            }
        }
        encryptedMessage += char;
    }
    return encryptedMessage;
}

  promeniLozinku(){

    if(this.korisnickoIme == "" || this.staraLozinka == "" || this.novaLozinka == "" || this.novaLozinka2==""){
      this.poruka = "Popunite sva polja"

    }
    else{

      this.staraLozinka = this.encryptMessage(this.staraLozinka)

      this.gostServis.loginGost(this.korisnickoIme,this.staraLozinka).subscribe((gost: Gost) =>{

        if(gost){

          if(!this.validatePassword(this.novaLozinka)){

            this.poruka = "Format nove lozinke nije odgovarajuci!"

          }else{
            if(this.novaLozinka != this.novaLozinka2){
              this.poruka = "Lozinke se ne poklapaju"
            }else{
              this.novaLozinka = this.encryptMessage(this.novaLozinka)
              this.gostServis.promenaSifre(this.korisnickoIme,this.novaLozinka, this.staraLozinka).subscribe((mes: Message) =>{

                if(mes){

                  alert("Sifra je uspesno promenjena!")
                  this.router.navigate(['login'])
                }

              })
            }
          }

        }else{
          alert("Korisnik ne postoji u sistemu!")
        }

      })

    }






  }

}
