import { Component, OnInit } from '@angular/core';
import { DostavaService } from '../servisi/dostava.service';
import { Gost } from '../models/gost';
import { Dostava } from '../models/dostava';

@Component({
  selector: 'app-gostdostave',
  templateUrl: './gostdostave.component.html',
  styleUrls: ['./gostdostave.component.css']
})
export class GostdostaveComponent implements OnInit{

  constructor(private dostavaServis: DostavaService){}

  ulogovan: Gost = new Gost()
  dostaveKorisnika: Dostava[] = []

  ngOnInit(): void {

    let ul = localStorage.getItem("ulogovan")
    if(ul)this.ulogovan = JSON.parse(ul)

    this.dostavaServis.dohvatiDostave().subscribe((dos: Dostava[])=>{
      if(dos){

        dos.forEach(d=>{
          if(d.korisnickoIme == this.ulogovan.korisnickoIme && d.status != 2){
            this.dostaveKorisnika.push(d)
          }
        })

      }
    })



  }

}
