import { Component,OnInit } from '@angular/core';

import { Message } from '../models/message';

import { Router } from '@angular/router';
import { GostService } from '../servisi/gost.service';
import { Admin } from '../models/admin';




@Component({
  selector: 'app-adminpocetna',
  templateUrl: './adminpocetna.component.html',
  styleUrls: ['./adminpocetna.component.css']
})
export class AdminpocetnaComponent implements OnInit{

  constructor(private gostServis: GostService,private router: Router){}

  username: string = "";
  password: string = "";

  poruka: string = ""

  admin: Admin = new Admin()



  ngOnInit(): void {


  }

  logIn(){

    this.gostServis.loginAdmin(this.username,this.password).subscribe((admin: Admin)=>{
      if(admin){

        localStorage.setItem("ulogovan",JSON.stringify(admin))
        this.router.navigate(['admin'])

      }else{

        this.poruka = "Admin ne postoji!"

      }
    })

  }




}
