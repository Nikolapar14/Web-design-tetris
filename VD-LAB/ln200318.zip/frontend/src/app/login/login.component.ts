import { Component,OnInit } from '@angular/core';

import { Message } from '../models/message';

import { Router } from '@angular/router';
import { GostService } from '../servisi/gost.service';
import { Gost } from '../models/gost';
import { KonobarService } from '../servisi/konobar.service';
import { Konobar } from '../models/konobar';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{

  constructor(private gostServis: GostService,private router: Router, private konobarServis: KonobarService){}

  username: string = "";
  password: string = "";

  poruka: string = ""



  ngOnInit(): void {




  }

  encryptMessage(message: string): string {
    let encryptedMessage = '';
    for (let i = 0; i < message.length; i++) {
        let char = message[i];

        if (/[a-zA-Z]/.test(char)) {

            let code = message.charCodeAt(i);
            if (char === char.toUpperCase()) {
                char = String.fromCharCode(((code - 65 + 3) % 26) + 65);
            } else {
                char = String.fromCharCode(((code - 97 + 3) % 26) + 97);
            }
        }
        encryptedMessage += char;
    }
    return encryptedMessage;
}

  logIn(){

    this.password = this.encryptMessage(this.password)

    this.gostServis.loginGost(this.username,this.password).subscribe((gost: Gost)=>{
      if(gost && gost.aktivan==1){

        localStorage.setItem("ulogovan",JSON.stringify(gost))
        this.router.navigate(['gost'])

      }else{

        this.konobarServis.loginKonobar(this.username, this.password).subscribe((kon: Konobar)=>{

          if(kon && kon.aktivan==1){

            localStorage.setItem("ulogovan",JSON.stringify(kon))
            this.router.navigate(['konobar'])

          }else{
            this.poruka = "Korisnik ne postoji!"
          }

        })

      }
    })

  }




}
